package com.netease.mc.modSS.utils.world;

import com.netease.mc.modSS.utils.Vec3;
import net.minecraft.util.EnumFacing;

public class EnumFacingOffset
{
    public EnumFacing enumFacing;
    public final Vec3 offset;
    
    public EnumFacingOffset(final EnumFacing enumFacing, final Vec3 offset) {
        this.enumFacing = enumFacing;
        this.offset = offset;
    }
}
