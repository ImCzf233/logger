package com.netease.mc.modSS.utils.pathfinding;

import net.minecraft.client.entity.EntityPlayerSP;
import java.util.ArrayList;
import net.minecraft.client.Minecraft;
import java.util.List;

public class PathUtils
{
    public static List<Vector3d> findBlinkPath(final double tpX, final double tpY, final double tpZ) {
        final EntityPlayerSP thePlayer = Minecraft.getMinecraft().thePlayer;
        final List<Vector3d> positions = new ArrayList<Vector3d>();
        double curX = thePlayer.posX;
        double curY = thePlayer.posY;
        double curZ = thePlayer.posZ;
        double distance = Math.abs(curX - tpX) + Math.abs(curY - tpY) + Math.abs(curZ - tpZ);
        int count = 0;
        while (distance > 0.0) {
            distance = Math.abs(curX - tpX) + Math.abs(curY - tpY) + Math.abs(curZ - tpZ);
            final double diffX = curX - tpX;
            final double diffY = curY - tpY;
            final double diffZ = curZ - tpZ;
            final double offset = ((count & 0x1) == 0x0) ? 0.4 : 0.1;
            final double minX = Math.min(Math.abs(diffX), offset);
            if (diffX < 0.0) {
                curX += minX;
            }
            if (diffX > 0.0) {
                curX -= minX;
            }
            final double minY = Math.min(Math.abs(diffY), 0.25);
            if (diffY < 0.0) {
                curY += minY;
            }
            if (diffY > 0.0) {
                curY -= minY;
            }
            final double minZ = Math.min(Math.abs(diffZ), offset);
            if (diffZ < 0.0) {
                curZ += minZ;
            }
            if (diffZ > 0.0) {
                curZ -= minZ;
            }
            positions.add(new Vector3d(curX, curY, curZ));
            ++count;
        }
        return positions;
    }
    
    public static List<Vector3d> findPath(final double tpX, final double tpY, final double tpZ, final double offset) {
        final EntityPlayerSP thePlayer = Minecraft.getMinecraft().thePlayer;
        final List<Vector3d> positions = new ArrayList<Vector3d>();
        final double posX = thePlayer.posX;
        final double posY = thePlayer.posY;
        final double posZ = thePlayer.posZ;
        final double steps = Math.ceil(getDistance(posX, posY, posZ, tpX, tpY, tpZ) / offset);
        final double dX = tpX - posX;
        final double dY = tpY - posY;
        final double dZ = tpZ - posZ;
        for (double d = 1.0; d <= steps; ++d) {
            positions.add(new Vector3d(posX + dX * d / steps, posY + dY * d / steps, posZ + dZ * d / steps));
        }
        return positions;
    }
    
    private static double getDistance(final double x1, final double y1, final double z1, final double x2, final double y2, final double z2) {
        final double xDiff = x1 - x2;
        final double yDiff = y1 - y2;
        final double zDiff = z1 - z2;
        return Math.sqrt(xDiff * xDiff + yDiff * yDiff + zDiff * zDiff);
    }
}
