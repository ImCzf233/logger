package com.netease.mc.modSS.utils.pathfinding.astar;

public interface IWorldProvider
{
    boolean isBlocked(final Cell p0);
}
