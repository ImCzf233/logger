package com.netease.mc.modSS.utils.pathfinding.astar;

public class Cell
{
    public final int x;
    public final int y;
    public final int z;
    public int g;
    public int h;
    public int f;
    public Cell parent;
    
    public Cell(final int x, final int y, final int z) {
        this.g = 0;
        this.h = 0;
        this.f = 0;
        this.x = x;
        this.y = y;
        this.z = z;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o instanceof Cell) {
            final Cell c = (Cell)o;
            return c.x == this.x && c.y == this.y && c.z == this.z;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return this.x * 31 + this.y * 31 + this.z * 31;
    }
    
    @Override
    public String toString() {
        return "Cell(" + this.x + ", " + this.y + ", " + this.z + ")";
    }
}
