package com.netease.mc.modSS.utils.pathfinding.astar;

import java.util.Iterator;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;

public class Pathfinder
{
    public static final Cell[] COMMON_NEIGHBORS;
    public static final Cell[] DIAGONAL_NEIGHBORS;
    private final Cell start;
    private final Cell end;
    private final Cell[] neighbours;
    private final IWorldProvider world;
    
    public Pathfinder(final Cell start, final Cell end, final Cell[] neighbours, final IWorldProvider world) {
        this.start = start;
        this.end = end;
        this.neighbours = neighbours;
        this.world = world;
    }
    
    public Cell getStart() {
        return this.start;
    }
    
    public Cell getEnd() {
        return this.end;
    }
    
    public Cell[] getNeighbours() {
        return this.neighbours;
    }
    
    public IWorldProvider getWorld() {
        return this.world;
    }
    
    public ArrayList<Cell> findPath() {
        return this.findPath(Integer.MAX_VALUE);
    }
    
    public ArrayList<Cell> findPath(final int maxLoops) {
        final ArrayList<Cell> open = new ArrayList<Cell>();
        final ArrayList<Cell> closed = new ArrayList<Cell>();
        open.add(this.start);
        Cell current = null;
        for (int loops = 0; !open.isEmpty() && loops < maxLoops; ++loops) {
            current = open.get(0);
            int currentIdx = 0;
            for (int i = 1; i < open.size(); ++i) {
                if (open.get(i).f < current.f) {
                    current = open.get(i);
                    currentIdx = i;
                }
            }
            open.remove(currentIdx);
            closed.add(current);
            if (current.equals(this.end)) {
                break;
            }
            final ArrayList<Cell> children = new ArrayList<Cell>();
            for (final Cell neighbor : this.neighbours) {
                final Cell child = new Cell(current.x + neighbor.x, current.y + neighbor.y, current.z + neighbor.z);
                child.parent = current;
                if (!this.world.isBlocked(child)) {
                    children.add(child);
                }
            }
            for (final Cell child2 : children) {
                if (closed.contains(child2)) {
                    continue;
                }
                child2.g = current.g + 1;
                child2.h = (int)(Math.pow(child2.x - this.end.x, 2.0) + Math.pow(child2.y - this.end.y, 2.0) + Math.pow(child2.z - this.end.z, 2.0));
                child2.f = child2.g + child2.h;
                if (open.contains(child2) && open.get(open.indexOf(child2)).g > child2.g) {
                    continue;
                }
                open.add(child2);
            }
        }
        final ArrayList<Cell> path = new ArrayList<Cell>();
        for (Cell cur = current; cur != null; cur = cur.parent) {
            path.add(cur);
        }
        Collections.reverse(path);
        return path;
    }
    
    static {
        COMMON_NEIGHBORS = new Cell[] { new Cell(1, 0, 0), new Cell(-1, 0, 0), new Cell(0, 1, 0), new Cell(0, -1, 0), new Cell(0, 0, 1), new Cell(0, 0, -1) };
        DIAGONAL_NEIGHBORS = new Cell[] { new Cell(1, 1, 0), new Cell(-1, -1, 0), new Cell(1, -1, 0), new Cell(-1, 1, 0), new Cell(0, 1, 1), new Cell(0, -1, -1), new Cell(0, 1, -1), new Cell(0, -1, 1), new Cell(1, 0, 0), new Cell(-1, 0, 0), new Cell(0, 1, 0), new Cell(0, -1, 0), new Cell(0, 0, 1), new Cell(0, 0, -1) };
    }
}
