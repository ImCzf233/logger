package com.netease.mc.modSS.utils.pathfinding.astar;

import java.util.ArrayList;

public class SimpleWorldProvider implements IWorldProvider
{
    private final ArrayList<Cell> walls;
    
    public SimpleWorldProvider() {
        this.walls = new ArrayList<Cell>();
    }
    
    public void addWall(final Cell cell) {
        this.walls.add(cell);
    }
    
    @Override
    public boolean isBlocked(final Cell cell) {
        return this.walls.contains(cell);
    }
}
