package com.netease.mc.modSS.utils.pathfinding;

public class Vector3d
{
    public double x;
    public double y;
    public double z;
    
    public Vector3d(final double x, final double y, final double z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
