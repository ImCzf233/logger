package com.netease.mc.modSS.utils.pathfinding;

import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.AxisAlignedBB;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.player.EntityPlayer;
import com.google.common.base.Predicate;
import net.minecraft.util.Vec3;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;

public class RaycastUtils
{
    public static Entity raycastEntity(final double range) {
        final EntityPlayerSP thePlayer = Minecraft.getMinecraft().thePlayer;
        return raycastEntity(range, thePlayer.rotationYaw, thePlayer.rotationPitch);
    }
    
    private static Entity raycastEntity(final double range, final float yaw, final float pitch) {
        final Minecraft mc = Minecraft.getMinecraft();
        final Entity renderViewEntity = mc.getRenderViewEntity();
        if (renderViewEntity != null && mc.theWorld != null) {
            double blockReachDistance = range;
            final Vec3 eyePosition = renderViewEntity.getPositionEyes(1.0f);
            final double yawCos = Math.cos(-yaw * 0.017453292f - 3.1415927f);
            final double yawSin = Math.sin(-yaw * 0.017453292f - 3.1415927f);
            final double pitchCos = -Math.cos(-pitch * 0.017453292f);
            final double pitchSin = Math.sin(-pitch * 0.017453292f);
            final Vec3 entityLook = new Vec3(yawSin * pitchCos, pitchSin, yawCos * pitchCos);
            final Vec3 vector = eyePosition.addVector(entityLook.xCoord * blockReachDistance, entityLook.yCoord * blockReachDistance, entityLook.zCoord * blockReachDistance);
            final List<Entity> entityList = (List<Entity>)mc.theWorld.getEntitiesInAABBexcluding(renderViewEntity, renderViewEntity.getEntityBoundingBox().addCoord(entityLook.xCoord * blockReachDistance, entityLook.yCoord * blockReachDistance, entityLook.zCoord * blockReachDistance).expand(1.0, 1.0, 1.0), (Predicate)null);
            entityList.removeIf(entity -> entity == null || (entity instanceof EntityPlayerSP && entity.isSpectator()) || !((Entity)entity).canBeCollidedWith());
            Entity pointedEntity = null;
            for (final Entity entity2 : entityList) {
                final double collisionBorderSize = entity2.getCollisionBorderSize();
                final AxisAlignedBB axisAlignedBB = entity2.getEntityBoundingBox().expand(collisionBorderSize, collisionBorderSize, collisionBorderSize);
                final MovingObjectPosition movingObjectPosition = axisAlignedBB.calculateIntercept(eyePosition, vector);
                if (axisAlignedBB.isVecInside(eyePosition)) {
                    if (blockReachDistance < 0.0) {
                        continue;
                    }
                    pointedEntity = entity2;
                    blockReachDistance = 0.0;
                }
                else {
                    if (movingObjectPosition == null) {
                        continue;
                    }
                    final double eyeDistance = eyePosition.distanceTo(movingObjectPosition.hitVec);
                    if (eyeDistance >= blockReachDistance && blockReachDistance != 0.0) {
                        continue;
                    }
                    if (entity2.equals((Object)renderViewEntity.ridingEntity) && !renderViewEntity.canRiderInteract()) {
                        if (blockReachDistance != 0.0) {
                            continue;
                        }
                        pointedEntity = entity2;
                    }
                    else {
                        pointedEntity = entity2;
                        blockReachDistance = eyeDistance;
                    }
                }
            }
            return pointedEntity;
        }
        return null;
    }
    
    public interface EntityFilter
    {
        boolean canRaycast(final Entity p0);
    }
}
