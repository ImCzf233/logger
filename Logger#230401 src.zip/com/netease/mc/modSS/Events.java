package com.netease.mc.modSS;

import java.lang.reflect.Field;
import net.minecraft.network.NetworkManager;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import net.minecraft.client.entity.EntityPlayerSP;
import com.netease.mc.modSS.protecter.injection.omg.hooks.NetHandler;
import dev.ss.world.event.mixinevents.EventNoSlowDown;
import dev.ss.world.event.mixinevents.EventMotion;
import dev.ss.world.event.mixinevents.EventAttack;
import dev.ss.world.event.mixinevents.EventUpdate;
import dev.ss.world.event.mixinevents.Event3D;
import dev.ss.world.event.mixinevents.Event2D;
import dev.ss.world.event.mixinevents.EventKey;
import dev.ss.world.event.mixinevents.EventMoveButton;
import dev.ss.world.event.mixinevents.EventCanPlaceBlock;
import dev.ss.world.event.mixinevents.EventWorld;
import dev.ss.world.event.mixinevents.EventJump;
import dev.ss.world.event.mixinevents.EventStep;
import dev.ss.world.event.mixinevents.EventMove;
import dev.ss.world.event.mixinevents.EventStrafe;
import dev.ss.world.event.mixinevents.EventPostMotion;
import dev.ss.world.event.mixinevents.EventPreMotion;
import dev.ss.world.event.eventapi.ShellEvent;
import dev.ss.world.event.mixinevents.EventPacket;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import com.netease.mc.modSS.protecter.injection.OMGHook;
import com.netease.mc.modSS.protecter.injection.omg.hooks.NetworkHook;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import org.lwjgl.input.Keyboard;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import com.netease.mc.modSS.utils.Utils;
import net.minecraftforge.client.event.GuiOpenEvent;
import java.util.Iterator;
import com.netease.mc.modSS.utils.Wrapper;
import com.netease.mc.modSS.mod.Mod;
import com.netease.mc.modSS.managers.ModManager;
import com.netease.mc.modSS.managers.Connection;
import net.minecraft.network.Packet;
import dev.ss.world.event.eventapi.EventManager;

public class Events
{
    private boolean legit;
    private boolean initialized;
    
    public Events() {
        this.legit = false;
        this.initialized = false;
        EventManager.register(this);
    }
    
    public boolean onPacket(final Packet packet, final Connection.Side side) {
        boolean suc = true;
        final ModManager modManager = ShellSock.getClient().modManager;
        for (final Mod module : ModManager.getModules()) {
            if (module.isEnabled()) {
                if (Wrapper.INSTANCE.world() == null) {
                    continue;
                }
                suc &= module.onPacket(packet, side);
            }
        }
        return suc;
    }
    
    @SubscribeEvent
    public void onGuiOpen(final GuiOpenEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            final ModManager modManager = ShellSock.getClient().modManager;
            ModManager.onGuiOpen(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onGuiOpen");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @SubscribeEvent
    public void onMouse(final MouseEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            final ModManager modManager = ShellSock.getClient().modManager;
            ModManager.onMouse(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onMouse");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @SubscribeEvent
    public void onCapePacket(final FMLNetworkEvent.ClientCustomPacketEvent clientCustomPacketEvent) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
    }
    
    @SubscribeEvent
    public void onKeyInput(final InputEvent.KeyInputEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            final int key = Keyboard.getEventKey();
            if (key == 0) {
                return;
            }
            if (Keyboard.getEventKeyState()) {
                final ModManager modManager = ShellSock.getClient().modManager;
                ModManager.onKeyPressed(key);
            }
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onKeyInput");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @SubscribeEvent
    public void onItemPickup(final EntityItemPickupEvent event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            final ModManager modManager = ShellSock.getClient().modManager;
            ModManager.onItemPickup(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onItemPickup");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @SubscribeEvent
    public void onAttackEntity(final AttackEntityEvent event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            final ModManager modManager = ShellSock.getClient().modManager;
            ModManager.onAttackEntity(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
        }
    }
    
    @SubscribeEvent
    public void onPlayerTick(final TickEvent.PlayerTickEvent event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            final ModManager modManager = ShellSock.getClient().modManager;
            ModManager.onPlayerTick(event);
        }
        catch (RuntimeException ex) {}
    }
    
    @SubscribeEvent
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (Utils.nullCheck()) {
            this.initialized = false;
            return;
        }
        try {
            if (ShellSock.s != null) {
                try {
                    ShellSock.s.set(null, ShellSock.remain);
                    Wrapper.message("Injected");
                    ShellSock.s = null;
                }
                catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
            if (!this.initialized) {
                new Connection(this);
                if (!ShellSock.mixin) {
                    new NetworkHook();
                }
                new OMGHook();
                this.initialized = true;
            }
            if (!this.legit) {
                final ModManager modManager = ShellSock.getClient().modManager;
                ModManager.onClientTick(event);
            }
            else if (this.legit) {}
        }
        catch (RuntimeException ex) {}
    }
    
    @SubscribeEvent
    public void onLivingUpdate(final LivingEvent.LivingUpdateEvent event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            final ModManager modManager = ShellSock.getClient().modManager;
            ModManager.onLivingUpdate(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onLivingUpdate");
            Wrapper.error(ex.toString());
        }
    }
    
    @SubscribeEvent
    public void onRender3D(final RenderBlockOverlayEvent event) {
        if (Utils.nullCheck() || Wrapper.INSTANCE.mcSettings().hideGUI) {
            return;
        }
        try {
            final ModManager modManager = ShellSock.getClient().modManager;
            ModManager.onRender3D(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onRenderWorldLast");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onPacketEvent(final EventPacket event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onPacketEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onPacketEvent");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onPreMotion(final EventPreMotion event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onPreMotion(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onPostMotion(final EventPostMotion event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onPostMotion(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onPostMotion");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onStrafeEvent(final EventStrafe event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onStrafeEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onStrafeEvent");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onMoveEvent(final EventMove event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onMoveEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onMoveEvent");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onStepEvent(final EventStep event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onStepEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onStepEvent");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onJumpEvent(final EventJump event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onJumpEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onJumpEvent");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onWorldEvent(final EventWorld event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onWorldEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onWorldEvent");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onCanPlaceBlockEvent(final EventCanPlaceBlock event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onCanPlaceBlockEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onCanPlaceBlockEvent");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onMoveButtonEvent(final EventMoveButton event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onMoveButtonEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onMoveButtonEvent");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onKeyInput(final EventKey event) {
        if (Utils.nullCheck()) {
            return;
        }
        try {
            final int key = Keyboard.getEventKey();
            if (key == 0) {
                return;
            }
            if (Keyboard.getEventKeyState()) {
                final ModManager modManager = ShellSock.getClient().modManager;
                ModManager.onKeyPressed(key);
            }
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onKeyInput");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onRender2D(final Event2D event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onRender2D(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onRender3D(final Event3D event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onRender3D(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onRender3D");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onUpdateEvent(final EventUpdate event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onUpdateEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onUpdateEvent");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onAttackEvent(final EventAttack event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onAttackEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onAttackEvent");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onMotionInjectEvent(final EventMotion event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onMotionInjectEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Utils.copy(ex.toString());
        }
    }
    
    @ShellEvent
    public void onNolsowEvent(final EventNoSlowDown event) {
        if (Utils.nullCheck() || this.legit) {
            return;
        }
        try {
            ShellSock.getClient().modManager.onNolsowEvent(event);
        }
        catch (RuntimeException ex) {
            ex.printStackTrace();
            Wrapper.error("RuntimeException: onNolsowEvent");
            Wrapper.error(ex.toString());
            Utils.copy(ex.toString());
        }
    }
    
    public void InjectNetHandler() {
        if (Wrapper.INSTANCE.player() == null) {
            return;
        }
        if (Wrapper.INSTANCE.player().sendQueue != null && !(Wrapper.INSTANCE.player().sendQueue instanceof NetHandler)) {
            final Field field = ReflectionHelper.findField((Class)EntityPlayerSP.class, new String[] { "sendQueue", "field_71174_a" });
            try {
                if (!field.isAccessible()) {
                    field.setAccessible(true);
                }
                final NetHandlerPlayClient netHandlerPlayClient = (NetHandlerPlayClient)field.get(Wrapper.INSTANCE.player());
                field.set(Wrapper.INSTANCE.player(), NetHandler.New(netHandlerPlayClient, Wrapper.INSTANCE.player()));
            }
            catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
            catch (IllegalAccessException e2) {
                e2.printStackTrace();
            }
            catch (Exception e3) {
                e3.printStackTrace();
            }
        }
        if (Wrapper.INSTANCE.controller() != null) {
            NetHandlerPlayClient netHandlerPlayClient2 = null;
            final Field field2 = ReflectionHelper.findField((Class)PlayerControllerMP.class, new String[] { "netClientHandler", "field_78774_b" });
            try {
                if (!field2.isAccessible()) {
                    field2.setAccessible(true);
                }
                netHandlerPlayClient2 = (NetHandlerPlayClient)field2.get(Wrapper.INSTANCE.controller());
                if (!(netHandlerPlayClient2 instanceof NetHandler)) {
                    field2.set(Wrapper.INSTANCE.controller(), NetHandler.New(netHandlerPlayClient2, Wrapper.INSTANCE.controller()));
                }
                final NetworkManager myNetworkManager = netHandlerPlayClient2.getNetworkManager();
                if (myNetworkManager != null) {
                    final Field field3 = ReflectionHelper.findField((Class)NetworkManager.class, new String[] { "packetListener", "field_150744_m" });
                    if (!field3.isAccessible()) {
                        field3.setAccessible(true);
                    }
                    final NetHandlerPlayClient netHandlerPlayClient3 = (NetHandlerPlayClient)field3.get(myNetworkManager);
                    if (netHandlerPlayClient3 != null && !(netHandlerPlayClient3 instanceof NetHandler)) {
                        field3.set(myNetworkManager, netHandlerPlayClient2);
                    }
                }
            }
            catch (IllegalArgumentException e4) {
                e4.printStackTrace();
            }
            catch (IllegalAccessException e5) {
                e5.printStackTrace();
            }
            catch (Exception e6) {
                e6.printStackTrace();
            }
        }
    }
}
