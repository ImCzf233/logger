package com.netease.mc.modSS.ui.clickgui.kendall.components;

public class Component
{
    public void render(final float x, final float y, final int mouseX, final int mouseY) {
    }
    
    public void mouseClicked(final int mouseX, final int mouseY, final int mouseButton) {
    }
    
    public void mouseReleased(final int mouseX, final int mouseY, final int state) {
    }
}
