package com.netease.mc.modSS.ui.clickgui.hydrogen.component;

public class Component
{
    public void renderComponent() {
    }
    
    public void updateComponent(final int mouseX, final int mouseY) {
    }
    
    public void mouseClicked(final int mouseX, final int mouseY, final int button) {
    }
    
    public void mouseReleased(final int mouseX, final int mouseY, final int mouseButton) {
    }
    
    public int getParentHeight() {
        return 0;
    }
    
    public void keyTyped(final char typedChar, final int key) {
    }
    
    public void setOff(final int newOff) {
    }
    
    public int getHeight() {
        return 0;
    }
}
