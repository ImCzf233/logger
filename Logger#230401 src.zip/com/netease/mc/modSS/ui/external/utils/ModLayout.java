package com.netease.mc.modSS.ui.external.utils;

import java.awt.Container;
import java.awt.Component;

public class ModLayout extends LayoutAdapter
{
    @Override
    public void addLayoutComponent(final Component comp, final Object constraints) {
    }
    
    @Override
    public void removeLayoutComponent(final Component comp) {
    }
    
    @Override
    public void layoutContainer(final Container parent) {
    }
}
