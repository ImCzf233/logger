package com.netease.mc.modSS.ui.external;

import java.util.Iterator;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.ListModel;
import com.netease.mc.modSS.ShellSock;
import javax.swing.DefaultListModel;
import javax.swing.JScrollPane;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import com.netease.mc.modSS.ui.external.utils.SimpleLayout;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.mod.Mod;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JFrame;

public class External2 extends JFrame
{
    JComboBox category;
    JPanel categorypanel;
    JPanel modspanel;
    JList<Mod> mods;
    Category selectedCategory;
    SimpleLayout layout;
    
    public External2() {
        this.selectedCategory = Category.COMBAT;
        final JFrame frame = new JFrame("ShellSock External powered by EST");
        frame.setSize(800, 800);
        frame.setVisible(true);
        this.categorypanel = new JPanel();
        this.modspanel = new JPanel();
        frame.setContentPane(this.categorypanel);
        this.layout = new SimpleLayout();
        this.category = new JComboBox();
        this.categorypanel.setLayout(this.layout);
        this.categorypanel.add(this.category);
        for (final Category c : Category.values()) {
            this.category.addItem(c);
        }
        this.mods = new JList<Mod>();
        final JScrollPane modscroll = new JScrollPane(this.mods);
        this.categorypanel.add(modscroll, "Center");
        final DefaultListModel names = new DefaultListModel();
        for (final Mod m : ShellSock.getClient().modManager.getModulesInCategory(this.selectedCategory)) {
            names.addElement(m.getName());
        }
        this.mods.setModel(names);
        this.category.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(final ItemEvent e) {
                if (e.getStateChange() == 1) {
                    External2.this.selectedCategory = (Category)External2.this.category.getSelectedItem();
                }
            }
        });
    }
    
    class ModThread extends Thread
    {
        @Override
        public void run() {
        }
    }
}
