package com.netease.mc.modSS.ui.ingame.style;

public interface Style
{
    void drawArrayList();
    
    void drawInfo();
    
    void drawPotionEffects();
    
    void drawWatermark();
    
    void drawHotbar();
}
