package com.netease.mc.modSS.file;

import java.io.IOException;
import java.util.Map;
import com.google.gson.JsonNull;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import com.google.gson.JsonParser;
import com.google.gson.Gson;
import java.util.Iterator;
import com.google.gson.GsonBuilder;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.FileWriter;
import com.google.gson.JsonElement;
import com.netease.mc.modSS.mod.Mod;
import com.netease.mc.modSS.managers.ModManager;
import com.google.gson.JsonObject;
import com.netease.mc.modSS.ShellSock;
import java.io.File;

public class ModConfig
{
    private final File moduleFile;
    
    public ModConfig() {
        System.out.println("new mod config");
        this.moduleFile = new File(ShellSock.getClient().directory + File.separator + "mods.json");
    }
    
    public void saveConfig() {
        try {
            final JsonObject jsonObject = new JsonObject();
            final ModManager modManager = ShellSock.getClient().modManager;
            for (final Mod module : ModManager.getModules()) {
                final JsonObject jsonMod = new JsonObject();
                jsonMod.addProperty("toggled", module.isEnabled());
                jsonMod.addProperty("visible", module.isVisible());
                jsonMod.addProperty("keybind", (Number)module.getKeybind());
                jsonObject.add(module.getName(), (JsonElement)jsonMod);
            }
            final PrintWriter printWriter = new PrintWriter(new FileWriter(this.moduleFile));
            final Gson gson = new GsonBuilder().setPrettyPrinting().create();
            printWriter.println(gson.toJson((JsonElement)jsonObject));
            printWriter.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void loadConfig() {
        try {
            final JsonParser jsonParser = new JsonParser();
            final JsonElement jsonElement = jsonParser.parse((Reader)new BufferedReader(new FileReader(this.moduleFile)));
            if (jsonElement instanceof JsonNull) {
                return;
            }
            for (final Map.Entry<String, JsonElement> entry : jsonElement.getAsJsonObject().entrySet()) {
                final Mod module = ShellSock.getClient().modManager.getModulebyName(entry.getKey());
                if (module != null) {
                    final JsonObject jsonModule = (JsonObject)entry.getValue();
                    final boolean toggled = jsonModule.get("toggled").getAsBoolean();
                    if (toggled && !module.getName().equalsIgnoreCase("freecam") && !module.getName().equalsIgnoreCase("��cpanic")) {
                        module.setEnabled();
                    }
                    module.setVisible(jsonModule.get("visible").getAsBoolean());
                    module.setKeyBind(jsonModule.get("keybind").getAsInt());
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
