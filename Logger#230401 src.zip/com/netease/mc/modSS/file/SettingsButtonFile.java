package com.netease.mc.modSS.file;

import java.util.Iterator;
import com.netease.mc.modSS.setting.Setting;
import com.netease.mc.modSS.ShellSock;
import com.netease.mc.modSS.managers.FileManager;

public class SettingsButtonFile
{
    private static FileManager ButtonList;
    
    public SettingsButtonFile() {
        try {
            loadState();
        }
        catch (Exception ex) {}
    }
    
    public static void saveState() {
        try {
            SettingsButtonFile.ButtonList.clear();
            for (final Setting setting : ShellSock.getClient().settingsManager.getSettings()) {
                final String line = setting.getName() + ":" + String.valueOf(setting.isEnabled());
                SettingsButtonFile.ButtonList.write(line);
            }
        }
        catch (Exception ex) {}
    }
    
    public static void loadState() {
        try {
            for (final String s : SettingsButtonFile.ButtonList.read()) {
                for (final Setting setting : ShellSock.getClient().settingsManager.getSettings()) {
                    final String name = s.split(":")[0];
                    final boolean toggled = Boolean.parseBoolean(s.split(":")[1]);
                    if (setting.getName().equalsIgnoreCase(name)) {
                        setting.setState(toggled);
                    }
                }
            }
        }
        catch (Exception ex) {}
    }
    
    static {
        SettingsButtonFile.ButtonList = new FileManager("button", ShellSock.getClient().NAME);
    }
}
