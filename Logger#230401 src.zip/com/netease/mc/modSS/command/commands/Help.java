package com.netease.mc.modSS.command.commands;

import java.util.Iterator;
import com.netease.mc.modSS.utils.Wrapper;
import net.minecraft.util.EnumChatFormatting;
import com.netease.mc.modSS.ShellSock;
import com.netease.mc.modSS.command.Command;

public class Help extends Command
{
    public static boolean isHelp;
    
    @Override
    public String getName() {
        return "help";
    }
    
    @Override
    public String getDesc() {
        return "Gives you the syntax of all commands and what they do.";
    }
    
    @Override
    public String getSyntax() {
        return ".help";
    }
    
    @Override
    public void execute(final String[] args) {
        if (args.length != 1) {
            for (final Command c : ShellSock.getClient().commandManager.getCommands()) {
                Wrapper.message(c.getSyntax() + " " + EnumChatFormatting.BLUE + c.getDesc());
            }
        }
    }
    
    static {
        Help.isHelp = false;
    }
}
