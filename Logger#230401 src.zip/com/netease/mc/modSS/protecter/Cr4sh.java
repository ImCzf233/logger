package com.netease.mc.modSS.protecter;

import java.lang.reflect.Field;
import sun.misc.Unsafe;

public class Cr4sh
{
    public Cr4sh() {
        try {
            final Field F = Unsafe.class.getDeclaredField("theUnsafe");
            F.setAccessible(true);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 19810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(1114L, 191810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(11414L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 119810L);
            ((Unsafe)F.get(null)).putAddress(11414L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 19810L);
            ((Unsafe)F.get(null)).putAddress(114514L, 191810L);
            ((Unsafe)F.get(null)).putAddress(11454L, 1919810L);
            ((Unsafe)F.get(null)).putAddress(1114L, 191810L);
        }
        catch (NoSuchFieldException e) {
            try {
                new Object().getClass().getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass();
            }
            catch (NoSuchFieldException nosadtion) {
                try {
                    final Field F2 = Unsafe.class.getDeclaredField("theUnsafe");
                    F2.setAccessible(true);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 19810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 19810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 19810L);
                    ((Unsafe)F2.get(null)).putAddress(1514L, 1919810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 19110L);
                    ((Unsafe)F2.get(null)).putAddress(1114L, 1919810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 19110L);
                    ((Unsafe)F2.get(null)).putAddress(1144L, 1919810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 91810L);
                    ((Unsafe)F2.get(null)).putAddress(1114L, 19810L);
                    ((Unsafe)F2.get(null)).putAddress(1514L, 1919810L);
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).putAddress(11414L, 191810L);
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).putAddress(11414L, 191810L);
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).putAddress(11414L, 191810L);
                    ((Unsafe)F2.get(null)).setMemory(14514L, 191810L, new Byte(null));
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                }
                catch (NoSuchFieldException se) {
                    try {
                        new Object().getClass().getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass();
                    }
                    catch (NoSuchFieldException ex) {}
                }
                catch (IllegalAccessException sse) {
                    try {
                        new Object().getClass().getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass();
                    }
                    catch (NoSuchFieldException ex2) {}
                }
            }
        }
        catch (IllegalAccessException e2) {
            try {
                new Object().getClass().getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass();
            }
            catch (NoSuchFieldException nosadtion) {
                try {
                    final Field F2 = Unsafe.class.getDeclaredField("theUnsafe");
                    F2.setAccessible(true);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                    ((Unsafe)F2.get(null)).putAddress(1114L, 19810L);
                    ((Unsafe)F2.get(null)).putAddress(1114L, 1919810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 19110L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                    ((Unsafe)F2.get(null)).putAddress(1514L, 1919810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 19810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 1919810L);
                    ((Unsafe)F2.get(null)).putAddress(114514L, 119810L);
                    ((Unsafe)F2.get(null)).putAddress(14514L, 1919810L);
                }
                catch (NoSuchFieldException ffe) {
                    try {
                        new Object().getClass().getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass();
                    }
                    catch (NoSuchFieldException ex3) {}
                }
                catch (IllegalAccessException ef) {
                    try {
                        new Object().getClass().getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass().getDeclaredField(null).getClass();
                    }
                    catch (NoSuchFieldException ex4) {}
                }
            }
        }
    }
}
