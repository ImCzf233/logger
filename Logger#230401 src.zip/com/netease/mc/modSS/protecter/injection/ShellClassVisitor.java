package com.netease.mc.modSS.protecter.injection;

import net.minecraftforge.fml.common.asm.transformers.deobf.FMLDeobfuscatingRemapper;
import java.util.Iterator;
import org.objectweb.asm.MethodVisitor;
import java.util.ArrayList;
import org.objectweb.asm.ClassVisitor;

public abstract class ShellClassVisitor extends ClassVisitor
{
    private final ArrayList<MethodVisitorRegistryEntry> methodVisitorRegistry;
    
    public ShellClassVisitor(final ClassVisitor cv) {
        super(262144, cv);
        this.methodVisitorRegistry = new ArrayList<MethodVisitorRegistryEntry>();
    }
    
    public MethodVisitor visitMethod(final int access, final String name, final String desc, final String signature, final String[] exceptions) {
        final MethodVisitor mv = super.visitMethod(access, name, desc, signature, exceptions);
        for (final MethodVisitorRegistryEntry entry : this.methodVisitorRegistry) {
            if (name.equals(entry.name) && desc.equals(entry.desc)) {
                return entry.factory.createMethodVisitor(mv);
            }
        }
        return mv;
    }
    
    protected String unmap(final String typeName) {
        return FMLDeobfuscatingRemapper.INSTANCE.unmap(typeName);
    }
    
    protected void registerMethodVisitor(final String name, final String desc, final MethodVisitorFactory factory) {
        this.methodVisitorRegistry.add(new MethodVisitorRegistryEntry(name, desc, factory));
    }
    
    private static final class MethodVisitorRegistryEntry
    {
        private final String name;
        private final String desc;
        private final MethodVisitorFactory factory;
        
        public MethodVisitorRegistryEntry(final String name, final String desc, final MethodVisitorFactory factory) {
            this.name = name;
            this.desc = desc;
            this.factory = factory;
        }
    }
    
    public interface MethodVisitorFactory
    {
        MethodVisitor createMethodVisitor(final MethodVisitor p0);
    }
}
