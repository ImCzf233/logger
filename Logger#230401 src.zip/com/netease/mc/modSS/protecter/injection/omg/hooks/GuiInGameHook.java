package com.netease.mc.modSS.protecter.injection.omg.hooks;

import dev.ss.world.event.eventapi.events.Event;
import dev.ss.world.event.eventapi.EventManager;
import dev.ss.world.event.mixinevents.Event2D;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiIngame;

public class GuiInGameHook extends GuiIngame
{
    public GuiInGameHook(final Minecraft mc) {
        super(mc);
    }
    
    public void renderGameOverlay(final float partialTicks) {
        EventManager.call(new Event2D());
        super.renderGameOverlay(partialTicks);
    }
}
