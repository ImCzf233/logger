package com.netease.mc.modSS.protecter;

import dev.ss.world.instrument.ClassTransformer;
import dev.ss.world.instrument.Instrumentation;
import dev.ss.world.instrument.impl.InstrumentationImpl;
import dev.ss.world.SSTransformer;
import dev.ss.world.SSAgent;

public class ModifyLauncher
{
    public ModifyLauncher() {
        final SSAgent ssAgent = new SSAgent();
        final SSTransformer ssTransformer = new SSTransformer();
        final InstrumentationImpl instrumentationImpl = new InstrumentationImpl();
        ssAgent.retransformclass(instrumentationImpl, ssTransformer, "net.minecraft.client.entity.EntityPlayerSP");
    }
}
