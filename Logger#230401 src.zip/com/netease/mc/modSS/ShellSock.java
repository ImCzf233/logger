package com.netease.mc.modSS;

import net.minecraftforge.common.MinecraftForge;
import com.netease.mc.modSS.utils.Wrapper;
import java.awt.Component;
import javax.swing.JOptionPane;
import com.netease.mc.modSS.ui.Colors;
import java.awt.Color;
import sun.misc.Unsafe;
import java.lang.reflect.Field;
import com.netease.mc.modSS.ui.ingame.HUD;
import java.io.File;
import com.netease.mc.modSS.protecter.ModifyLauncher;
import com.netease.mc.modSS.managers.NotificationManager;
import com.netease.mc.modSS.managers.ConfigManager;
import com.netease.mc.modSS.managers.CommandManager;
import com.netease.mc.modSS.managers.KeybindManager;
import com.netease.mc.modSS.managers.ScriptManager;
import com.netease.mc.modSS.managers.ModManager;
import com.netease.mc.modSS.setting.SettingsManager;

public class ShellSock
{
    public static ShellSock shellSock;
    public SettingsManager settingsManager;
    public ModManager modManager;
    public ScriptManager scriptManager;
    public KeybindManager keybindManager;
    public CommandManager commandManager;
    public Events events;
    public ConfigManager configManager;
    public NotificationManager notificationManager;
    public ModifyLauncher modifyLauncher;
    public String DEVS;
    public String NAME;
    public String VERSION;
    public String prefix;
    public String USERNAME;
    public File directory;
    public static boolean isObfuscate;
    public int THEME_COLOR;
    public static boolean mixin;
    public static boolean inject;
    public static boolean state;
    public static HUD hud;
    public static Field s;
    public static Unsafe remain;
    
    public static ShellSock getClient() {
        return ShellSock.shellSock;
    }
    
    public ShellSock() {
        this.DEVS = "Logger#9152 & EST";
        this.NAME = "LOGGER";
        this.VERSION = "1.0.9";
        this.prefix = "[" + this.NAME + "]";
        this.USERNAME = " ";
        this.THEME_COLOR = Colors.getColor(Color.white);
        if (ShellSock.state) {
            return;
        }
        this.init();
    }
    
    public void init() {
        JOptionPane.showMessageDialog(null, "Cracked by liyuxuan.rip", "Press enter btw", 1);
        System.out.println("ShellSock: Current Computer is Available");
        try {
            ShellSock.s = Class.forName("cc.nplus.e").getDeclaredField("O");
            ShellSock.remain = (Unsafe)ShellSock.s.get(null);
            ShellSock.s.setAccessible(true);
            ShellSock.s.set(null, null);
            Wrapper.message("NULL");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        ShellSock.state = true;
        ShellSock.shellSock = this;
        this.directory = new File(new File("C:\\Logger"), "Configs");
        if (!this.directory.exists()) {
            this.directory.mkdir();
        }
        this.settingsManager = new SettingsManager();
        this.modManager = new ModManager();
        this.keybindManager = new KeybindManager();
        this.commandManager = new CommandManager();
        this.modManager.addModules();
        this.events = new Events();
        this.configManager = new ConfigManager();
        this.notificationManager = new NotificationManager();
        MinecraftForge.EVENT_BUS.register((Object)this.events);
    }
    
    static {
        ShellSock.isObfuscate = false;
        ShellSock.mixin = false;
        ShellSock.state = false;
    }
}
