package com.netease.mc.modSS.mod.mods.COMBAT;

import dev.ss.world.event.mixinevents.Event3D;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.util.Vec3;
import net.minecraft.client.entity.EntityPlayerSP;
import java.util.Collections;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import com.netease.mc.modSS.utils.pathfinding.PathUtils;
import com.netease.mc.modSS.utils.RotationUtils;
import net.minecraft.entity.Entity;
import com.netease.mc.modSS.utils.ValidUtils;
import com.netease.mc.modSS.utils.pathfinding.RaycastUtils;
import dev.ss.world.event.mixinevents.EventMotion;
import java.util.ArrayList;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.utils.pathfinding.Vector3d;
import java.util.List;
import net.minecraft.entity.EntityLivingBase;
import com.netease.mc.modSS.setting.Setting;
import com.netease.mc.modSS.mod.Mod;

public class TeleportHit extends Mod
{
    private Setting render;
    private Setting FLY;
    private EntityLivingBase targetEntity;
    private boolean shouldHit;
    private List<Vector3d> path;
    private long time;
    
    public TeleportHit() {
        super("TeleportHit", "", Category.COMBAT);
        this.render = new Setting("Render", this, true);
        this.FLY = new Setting("IgnoreJump", this, true);
        this.targetEntity = null;
        this.path = new ArrayList<Vector3d>();
        this.time = 0L;
        this.addSetting(this.render);
    }
    
    @Override
    public void onMotionInjectEvent(final EventMotion event) {
        final Entity facedEntity = RaycastUtils.raycastEntity(100.0);
        final EntityPlayerSP thePlayer = TeleportHit.mc.thePlayer;
        if (thePlayer == null || facedEntity == null) {
            return;
        }
        if (TeleportHit.mc.gameSettings.keyBindAttack.isKeyDown() && ValidUtils.isValidEntity((EntityLivingBase)facedEntity) && facedEntity.getDistanceSqToEntity((Entity)thePlayer) >= 1.0) {
            this.targetEntity = (EntityLivingBase)facedEntity;
        }
        if (this.targetEntity != null) {
            if (!this.shouldHit) {
                this.shouldHit = true;
                return;
            }
            if (thePlayer.fallDistance > 0.0f) {
                final float[] f = { thePlayer.rotationYaw, 0.0f };
                final Vec3 rotationVector = RotationUtils.getVectorForRotation(f);
                final double x = thePlayer.posX + rotationVector.xCoord * (thePlayer.getDistanceToEntity((Entity)this.targetEntity) - 1.0f);
                final double z = thePlayer.posZ + rotationVector.zCoord * (thePlayer.getDistanceToEntity((Entity)this.targetEntity) - 1.0f);
                final double y = this.targetEntity.posY + 0.25;
                this.path = PathUtils.findPath(x, y + 1.0, z, 4.0);
                this.time = System.currentTimeMillis();
                final NetHandlerPlayClient netHandler = TeleportHit.mc.getNetHandler();
                this.path.forEach(pos -> netHandler.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(pos.x, pos.y, pos.z, false)));
                thePlayer.swingItem();
                thePlayer.sendQueue.addToSendQueue((Packet)new C02PacketUseEntity((Entity)this.targetEntity, C02PacketUseEntity.Action.ATTACK));
                thePlayer.onEnchantmentCritical((Entity)this.targetEntity);
                final List<Vector3d> reverse = this.path;
                Collections.reverse(reverse);
                reverse.forEach(pos -> netHandler.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(pos.x, pos.y, pos.z, false)));
                netHandler.addToSendQueue((Packet)new C03PacketPlayer.C04PacketPlayerPosition(thePlayer.posX, thePlayer.posY, thePlayer.posZ, thePlayer.onGround));
                this.shouldHit = false;
                this.targetEntity = null;
            }
            else if (thePlayer.onGround) {
                thePlayer.jump();
            }
        }
        else {
            this.shouldHit = false;
        }
    }
    
    @Override
    public void onRender3D(final Event3D event) {
        if (this.render.isEnabled()) {
            if (System.currentTimeMillis() - this.time > 2000L) {
                this.path.clear();
                return;
            }
            if (this.path.isEmpty()) {
                return;
            }
            final double[][] points = new double[this.path.size()][3];
            for (int i = 0; i < this.path.size(); ++i) {
                points[i][0] = this.path.get(i).x;
                points[i][1] = this.path.get(i).y;
                points[i][2] = this.path.get(i).z;
            }
        }
    }
}
