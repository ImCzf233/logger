package com.netease.mc.modSS.mod.mods.COMBAT;

import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.AxisAlignedBB;
import java.util.List;
import net.minecraft.util.Vec3;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;
import com.netease.mc.modSS.mod.Category;
import java.util.Random;
import com.netease.mc.modSS.setting.Setting;
import com.netease.mc.modSS.mod.Mod;

public class Reach extends Mod
{
    public static double modifyreach;
    public Setting reachMinVal;
    public Setting reachMaxVal;
    public Setting throughBlocks;
    public Random r;
    
    public Reach() {
        super("Reach", "", Category.COMBAT);
        this.reachMinVal = new Setting("MinReach", this, 4.0, 3.0, 6.0, false);
        this.reachMaxVal = new Setting("MaxReach", this, 4.0, 3.0, 6.0, false);
        this.throughBlocks = new Setting("ThroughBlocks", this, false);
        this.r = new Random();
        this.addSetting(this.reachMinVal);
        this.addSetting(this.reachMaxVal);
        this.addSetting(this.throughBlocks);
    }
    
    public float getRange() {
        Reach.modifyreach = this.reachMinVal.getValue() + this.r.nextDouble() * (this.reachMaxVal.getValue() - this.reachMinVal.getValue());
        return (float)Reach.modifyreach;
    }
    
    public static Object[] getMouseOver(final double Range, final double bbExpand, final float f) {
        final Entity renderViewEntity = Reach.mc.getRenderViewEntity();
        Entity entity = null;
        if (renderViewEntity == null || Reach.mc.theWorld == null) {
            return null;
        }
        Reach.mc.mcProfiler.startSection("pick");
        final Vec3 positionEyes = renderViewEntity.getPositionEyes(0.0f);
        final Vec3 renderViewEntityLook = renderViewEntity.getLook(0.0f);
        final Vec3 vector = positionEyes.addVector(renderViewEntityLook.xCoord * Range, renderViewEntityLook.yCoord * Range, renderViewEntityLook.zCoord * Range);
        Vec3 ve = null;
        final List entitiesWithinAABB = Reach.mc.theWorld.getEntitiesWithinAABBExcludingEntity(renderViewEntity, renderViewEntity.getEntityBoundingBox().addCoord(renderViewEntityLook.xCoord * Range, renderViewEntityLook.yCoord * Range, renderViewEntityLook.zCoord * Range).expand(1.0, 1.0, 1.0));
        double range = Range;
        for (int i = 0; i < entitiesWithinAABB.size(); ++i) {
            final Entity e = entitiesWithinAABB.get(i);
            if (e.canBeCollidedWith()) {
                final float size = e.getCollisionBorderSize();
                AxisAlignedBB bb = e.getEntityBoundingBox().expand((double)size, (double)size, (double)size);
                bb = bb.expand(bbExpand, bbExpand, bbExpand);
                final MovingObjectPosition objectPosition = bb.calculateIntercept(positionEyes, vector);
                if (bb.isVecInside(positionEyes)) {
                    if (0.0 < range || range == 0.0) {
                        entity = e;
                        ve = ((objectPosition == null) ? positionEyes : objectPosition.hitVec);
                        range = 0.0;
                    }
                }
                else if (objectPosition != null) {
                    final double v;
                    if ((v = positionEyes.distanceTo(objectPosition.hitVec)) < range || range == 0.0) {
                        final boolean b = false;
                        if (e == renderViewEntity.ridingEntity) {
                            if (range == 0.0) {
                                entity = e;
                                ve = objectPosition.hitVec;
                            }
                        }
                        else {
                            entity = e;
                            ve = objectPosition.hitVec;
                            range = v;
                        }
                    }
                }
            }
        }
        if (range < Range && !(entity instanceof EntityLivingBase) && !(entity instanceof EntityItemFrame)) {
            entity = null;
        }
        Reach.mc.mcProfiler.endSection();
        if (entity == null || ve == null) {
            return null;
        }
        return new Object[] { entity, ve };
    }
    
    static {
        Reach.modifyreach = 3.0;
    }
}
