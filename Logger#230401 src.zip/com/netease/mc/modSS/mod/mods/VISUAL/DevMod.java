package com.netease.mc.modSS.mod.mods.VISUAL;

import dev.ss.world.event.mixinevents.Event2D;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.mod.Mod;

public class DevMod extends Mod
{
    public DevMod() {
        super("DevMod", "", Category.VISUAL);
    }
    
    @Override
    public void onRender2D(final Event2D event) {
        super.onRender2D(event);
    }
}
