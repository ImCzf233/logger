package com.netease.mc.modSS.mod.mods.CLIENT;

import java.lang.reflect.Field;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import com.netease.mc.modSS.ShellSock;
import net.minecraft.network.play.client.C01PacketChatMessage;
import com.netease.mc.modSS.managers.Connection;
import net.minecraft.network.Packet;
import com.netease.mc.modSS.utils.Utils;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.mod.Mod;

public class CommandGetter extends Mod
{
    public CommandGetter() {
        super("CommandGetter", "", Category.CLIENT);
        this.setVisible(false);
        this.setEnabled();
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (Utils.nullCheck()) {
            return;
        }
        super.onClientTick(event);
    }
    
    @Override
    public boolean onPacket(final Packet packet, final Connection.Side side) {
        boolean send = true;
        if (side == Connection.Side.OUT && packet instanceof C01PacketChatMessage && !ShellSock.mixin) {
            final Field field = ReflectionHelper.findField((Class)C01PacketChatMessage.class, new String[] { "message", "field_149440_a" });
            try {
                if (!field.isAccessible()) {
                    field.setAccessible(true);
                }
                if (packet instanceof C01PacketChatMessage) {
                    final C01PacketChatMessage p = (C01PacketChatMessage)packet;
                    if (p.getMessage().subSequence(0, 1).equals(".")) {
                        send = false;
                        ShellSock.getClient().commandManager.execute(p.getMessage());
                        return send;
                    }
                    send = true;
                }
            }
            catch (Exception ex) {}
        }
        return send;
    }
}
