package com.netease.mc.modSS.mod.mods.CLIENT;

import com.netease.mc.modSS.ui.docmer.NMSLDomcer;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.mod.Mod;

public class DomcerHelper extends Mod
{
    public DomcerHelper() {
        super("DomcerHelper", "", Category.CLIENT);
    }
    
    @Override
    public void onEnable() {
        NMSLDomcer.main(null);
        super.onEnable();
    }
}
