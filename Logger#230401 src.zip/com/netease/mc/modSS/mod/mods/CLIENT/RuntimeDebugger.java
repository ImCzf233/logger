package com.netease.mc.modSS.mod.mods.CLIENT;

import java.lang.reflect.Field;
import com.netease.mc.modSS.utils.Wrapper;
import com.netease.mc.modSS.managers.Connection;
import net.minecraft.network.Packet;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.setting.Setting;
import com.netease.mc.modSS.mod.Mod;

public class RuntimeDebugger extends Mod
{
    public Setting mac_debug;
    public Setting packet_debug;
    public static boolean isMACExist;
    
    public RuntimeDebugger() {
        super("RuntimeDebugger", "", Category.CLIENT);
        this.mac_debug = new Setting("MAC_Debug", this, false);
        this.packet_debug = new Setting("Packet_Debug", this, false);
        this.addSetting(this.mac_debug);
        this.addSetting(this.packet_debug);
    }
    
    @Override
    public boolean onPacket(final Packet packet, final Connection.Side side) {
        if (RuntimeDebugger.mc.thePlayer == null) {
            return true;
        }
        if (this.packet_debug.isEnabled()) {
            System.out.println("[" + side.name() + "]Packet:" + packet.getClass().getName());
        }
        if (this.mac_debug.isEnabled() && RuntimeDebugger.isMACExist) {
            Class MAC = null;
            try {
                MAC = Class.forName("cn.margele.netease.clientside.MargeleAntiCheat");
                final Field DEBUG = MAC.getDeclaredField("f");
                DEBUG.setAccessible(true);
                DEBUG.set(MAC, true);
            }
            catch (ClassNotFoundException | IllegalAccessException | NoSuchFieldException ex2) {
                final ReflectiveOperationException ex;
                final ReflectiveOperationException e = ex;
                e.printStackTrace();
                Wrapper.message(e.getMessage());
                RuntimeDebugger.isMACExist = false;
            }
        }
        return super.onPacket(packet, side);
    }
    
    static {
        RuntimeDebugger.isMACExist = true;
    }
}
