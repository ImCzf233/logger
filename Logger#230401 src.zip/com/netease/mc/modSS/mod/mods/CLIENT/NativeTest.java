package com.netease.mc.modSS.mod.mods.CLIENT;

import com.netease.mc.modSS.protecter.ModifyLauncher;
import com.netease.mc.modSS.ShellSock;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.mod.Mod;

public class NativeTest extends Mod
{
    public static boolean loadedNA;
    
    public NativeTest() {
        super("CAFE1001", "", Category.CLIENT);
    }
    
    @Override
    public void onEnable() {
        super.onEnable();
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (!ShellSock.mixin && !NativeTest.loadedNA && NativeTest.mc.thePlayer != null && NativeTest.mc.theWorld != null) {
            System.out.println("\"Loading\" = Loading");
            ShellSock.getClient().modifyLauncher = new ModifyLauncher();
            NativeTest.loadedNA = true;
        }
    }
    
    static {
        NativeTest.loadedNA = false;
    }
}
