package com.netease.mc.modSS.mod.mods.ADDON;

import com.netease.mc.modSS.utils.Wrapper;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.mod.Mod;

public class HyCraft extends Mod
{
    public HyCraft() {
        super("HyCraftAddon", "", Category.CLIENT);
    }
    
    @Override
    public void onEnable() {
        Wrapper.modmsg(this, "Loaded Hycraft Addon");
        super.onEnable();
    }
}
