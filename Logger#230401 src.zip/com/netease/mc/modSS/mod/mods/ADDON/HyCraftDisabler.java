package com.netease.mc.modSS.mod.mods.ADDON;

import sun.reflect.Reflection;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import com.netease.mc.modSS.utils.Wrapper;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.mod.Mod;

public class HyCraftDisabler extends Mod
{
    public HyCraftDisabler() {
        super("HyCraftDisabler", "", Category.CLIENT);
    }
    
    @Override
    public void onEnable() {
        Wrapper.modmsg(this, "Start Disabling Hycraft ScreenShot/ClickGUI-Crash");
        try {
            Reflection.registerFieldsToFilter(EventBus.class, "listeners");
        }
        catch (Exception ex) {}
        Wrapper.modmsg(this, "Disabled Hycraft ScreenShot/ClickGUI-Crash");
        super.onEnable();
    }
}
