package com.netease.mc.modSS.mod.mods.MOVEMENT;

import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.mod.Mod;

public class HighJump extends Mod
{
    public HighJump() {
        super("HighJump", "make you jump at a height", Category.MOVEMENT);
    }
}
