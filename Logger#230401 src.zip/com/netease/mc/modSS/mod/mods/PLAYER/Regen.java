package com.netease.mc.modSS.mod.mods.PLAYER;

import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import com.netease.mc.modSS.utils.Wrapper;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.setting.Setting;
import com.netease.mc.modSS.mod.Mod;

public class Regen extends Mod
{
    private Setting healthValue;
    private Setting speedValue;
    private Setting ignoreFood;
    
    public Regen() {
        super("Regen", "", Category.PLAYER);
        this.healthValue = new Setting("Health", this, 10.0, 1.0, 20.0, true);
        this.speedValue = new Setting("Speed", this, 100.0, 0.0, 100.0, true);
        this.ignoreFood = new Setting("IgnoreFood", this, true);
        this.addSetting(this.healthValue);
        this.addSetting(this.speedValue);
        this.addSetting(this.ignoreFood);
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (Wrapper.INSTANCE.player().capabilities.isCreativeMode || Wrapper.INSTANCE.player().getHealth() == 0.0f) {
            return;
        }
        if (Wrapper.INSTANCE.player().getFoodStats().getFoodLevel() < 18 && !this.ignoreFood.isEnabled()) {
            return;
        }
        if (Wrapper.INSTANCE.player().getHealth() >= Wrapper.INSTANCE.player().getMaxHealth()) {
            return;
        }
        if (Wrapper.INSTANCE.player().getHealth() <= (float)this.healthValue.getValue()) {
            for (int i = 0; i < (int)this.speedValue.getValue(); ++i) {
                Wrapper.INSTANCE.sendPacket((Packet)new C03PacketPlayer());
            }
            super.onClientTick(event);
        }
    }
}
