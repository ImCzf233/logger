package com.netease.mc.modSS.mod.mods.PLAYER;

import java.lang.reflect.Field;
import net.minecraftforge.fml.relauncher.ReflectionHelper;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import com.netease.mc.modSS.utils.Wrapper;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import com.netease.mc.modSS.setting.Setting;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.mod.Info;
import com.netease.mc.modSS.mod.Mod;

@Info(name = "SpeedMine", description = "", category = Category.PLAYER)
public class SpeedMine extends Mod
{
    public Setting mode;
    public Setting blockDamage;
    
    public SpeedMine() {
        super("SpeedMine", "", Category.PLAYER);
        this.mode = new Setting("Mode", this, "Legit", new String[] { "Legit" });
        this.blockDamage = new Setting("BlockDamage", this, 0.7, 0.2, 1.0, false);
        this.addSetting(this.mode);
        this.addSetting(this.blockDamage);
    }
    
    @Override
    public void onClientTick(final TickEvent.ClientTickEvent event) {
        if (!Wrapper.INSTANCE.mc().playerController.isInCreativeMode() && this.mode.isMode("Legit")) {
            final Field field = ReflectionHelper.findField((Class)PlayerControllerMP.class, new String[] { "curBlockDamageMP", "field_78770_f" });
            final Field blockdelay = ReflectionHelper.findField((Class)PlayerControllerMP.class, new String[] { "blockHitDelay", "field_78781_i" });
            try {
                if (!field.isAccessible()) {
                    field.setAccessible(true);
                }
                if (!blockdelay.isAccessible()) {
                    blockdelay.setAccessible(true);
                }
                blockdelay.setInt(Wrapper.INSTANCE.mc().playerController, 0);
                if (field.getFloat(Wrapper.INSTANCE.mc().playerController) >= this.blockDamage.getValue()) {
                    field.setFloat(Wrapper.INSTANCE.mc().playerController, 1.0f);
                }
            }
            catch (Exception ex) {}
        }
        super.onClientTick(event);
    }
}
