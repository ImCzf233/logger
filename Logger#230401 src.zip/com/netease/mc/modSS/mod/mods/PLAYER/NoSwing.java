package com.netease.mc.modSS.mod.mods.PLAYER;

import net.minecraft.network.play.client.C0APacketAnimation;
import com.netease.mc.modSS.managers.Connection;
import net.minecraft.network.Packet;
import com.netease.mc.modSS.mod.Category;
import com.netease.mc.modSS.mod.Mod;

public class NoSwing extends Mod
{
    public NoSwing() {
        super("NoSwing", "delete the animation packet", Category.PLAYER);
    }
    
    @Override
    public boolean onPacket(final Packet packet, final Connection.Side side) {
        return side != Connection.Side.OUT || !(packet instanceof C0APacketAnimation);
    }
}
