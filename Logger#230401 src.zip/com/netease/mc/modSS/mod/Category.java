package com.netease.mc.modSS.mod;

public enum Category
{
    COMBAT, 
    MOVEMENT, 
    VISUAL, 
    PLAYER, 
    CLIENT;
}
