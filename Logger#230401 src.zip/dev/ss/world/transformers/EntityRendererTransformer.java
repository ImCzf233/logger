package dev.ss.world.transformers;

import net.minecraft.util.AxisAlignedBB;
import java.util.List;
import net.minecraft.util.Vec3;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import com.google.common.base.Predicates;
import net.minecraft.entity.Entity;
import com.google.common.base.Predicate;
import net.minecraft.util.EntitySelectors;
import java.util.Iterator;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.VarInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.InsnList;
import com.netease.mc.modSS.utils.Wrapper;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.ClassNode;
import net.minecraft.client.Minecraft;
import org.objectweb.asm.Opcodes;

public class EntityRendererTransformer implements Opcodes
{
    public static Minecraft mc;
    
    public static void transformEntityRenderer(final ClassNode classNode, final MethodNode m) {
        Wrapper.message("getMouseOver");
        for (final MethodNode method : classNode.methods) {
            if ((method.name.equals("getMouseOver") || method.name.equals("func_78473_a")) && isMAC()) {
                final InsnList hookInsn = new InsnList();
                final LabelNode L0 = new LabelNode();
                hookInsn.add((AbstractInsnNode)new VarInsnNode(23, 1));
                hookInsn.add((AbstractInsnNode)new MethodInsnNode(184, Type.getInternalName((Class)EntityRendererTransformer.class), "getMouseOverHook", "(F)Z"));
                hookInsn.add((AbstractInsnNode)new JumpInsnNode(153, L0));
                hookInsn.add((AbstractInsnNode)new InsnNode(177));
                hookInsn.add((AbstractInsnNode)L0);
                method.instructions.insert(hookInsn);
                Wrapper.message("getMouseOver");
            }
        }
    }
    
    public static boolean isMAC() {
        return getMAC() != null;
    }
    
    public static Class<?> getMAC() {
        try {
            return Class.forName("cn.margele.netease.clientside.MargeleAntiCheat");
        }
        catch (ClassNotFoundException e) {
            return null;
        }
    }
    
    public static boolean getMouseOverHook(final float partialTick) {
        getMouseOverHookx(partialTick);
        return true;
    }
    
    public static void getMouseOverHookx(final float partialTicks) {
        final Entity entity = EntityRendererTransformer.mc.getRenderViewEntity();
        if (entity != null && EntityRendererTransformer.mc.theWorld != null) {
            EntityRendererTransformer.mc.mcProfiler.startSection("pick");
            EntityRendererTransformer.mc.pointedEntity = null;
            double d0 = EntityPlayerMPTransformer.getBlockReachDistance();
            EntityRendererTransformer.mc.objectMouseOver = entity.rayTrace(d0, partialTicks);
            double d2 = d0;
            final Vec3 vec3 = entity.getPositionEyes(partialTicks);
            boolean flag = false;
            final int i = 3;
            if (EntityRendererTransformer.mc.playerController.extendedReach()) {
                d0 = 6.0;
                d2 = 6.0;
            }
            else if (d0 > 3.0) {
                flag = true;
            }
            if (EntityRendererTransformer.mc.objectMouseOver != null) {
                d2 = EntityRendererTransformer.mc.objectMouseOver.hitVec.distanceTo(vec3);
            }
            final Vec3 vec4 = entity.getLook(partialTicks);
            final Vec3 vec5 = vec3.addVector(vec4.xCoord * d0, vec4.yCoord * d0, vec4.zCoord * d0);
            EntityRendererTransformer.mc.pointedEntity = null;
            Vec3 vec6 = null;
            final float f = 1.0f;
            final List<Entity> list = (List<Entity>)EntityRendererTransformer.mc.theWorld.getEntitiesInAABBexcluding(entity, entity.getEntityBoundingBox().addCoord(vec4.xCoord * d0, vec4.yCoord * d0, vec4.zCoord * d0).expand((double)f, (double)f, (double)f), Predicates.and(EntitySelectors.NOT_SPECTATING, (Predicate)new Predicate<Entity>() {
                public boolean apply(final Entity p_apply_1_) {
                    return p_apply_1_.canBeCollidedWith();
                }
            }));
            double d3 = d2;
            for (int j = 0; j < list.size(); ++j) {
                final Entity entity2 = list.get(j);
                final float f2 = entity2.getCollisionBorderSize();
                final AxisAlignedBB axisalignedbb = entity2.getEntityBoundingBox().expand((double)f2, (double)f2, (double)f2);
                final MovingObjectPosition movingobjectposition = axisalignedbb.calculateIntercept(vec3, vec5);
                if (axisalignedbb.isVecInside(vec3)) {
                    if (d3 >= 0.0) {
                        EntityRendererTransformer.mc.pointedEntity = entity2;
                        vec6 = ((movingobjectposition == null) ? vec3 : movingobjectposition.hitVec);
                        d3 = 0.0;
                    }
                }
                else if (movingobjectposition != null) {
                    final double d4 = vec3.distanceTo(movingobjectposition.hitVec);
                    if (d4 < d3 || d3 == 0.0) {
                        if (entity2 == entity.ridingEntity && !entity.canRiderInteract()) {
                            if (d3 == 0.0) {
                                EntityRendererTransformer.mc.pointedEntity = entity2;
                                vec6 = movingobjectposition.hitVec;
                            }
                        }
                        else {
                            EntityRendererTransformer.mc.pointedEntity = entity2;
                            vec6 = movingobjectposition.hitVec;
                            d3 = d4;
                        }
                    }
                }
            }
            if (EntityRendererTransformer.mc.pointedEntity != null && flag && vec3.distanceTo(vec6) > 3.0) {
                EntityRendererTransformer.mc.pointedEntity = null;
                EntityRendererTransformer.mc.objectMouseOver = new MovingObjectPosition(MovingObjectPosition.MovingObjectType.MISS, vec6, (EnumFacing)null, new BlockPos(vec6));
            }
            if (EntityRendererTransformer.mc.pointedEntity != null && (d3 < d2 || EntityRendererTransformer.mc.objectMouseOver == null)) {
                EntityRendererTransformer.mc.objectMouseOver = new MovingObjectPosition(EntityRendererTransformer.mc.pointedEntity, vec6);
                if (EntityRendererTransformer.mc.pointedEntity instanceof EntityLivingBase || EntityRendererTransformer.mc.pointedEntity instanceof EntityItemFrame) {
                    EntityRendererTransformer.mc.pointedEntity = EntityRendererTransformer.mc.pointedEntity;
                }
            }
            EntityRendererTransformer.mc.mcProfiler.endSection();
        }
    }
    
    static {
        EntityRendererTransformer.mc = Minecraft.getMinecraft();
    }
}
