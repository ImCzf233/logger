package dev.ss.world.transformers;

import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.Packet;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.VarInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.Opcodes;

public class NetworkManagerTransformer implements Opcodes
{
    public static void transformNetworkManager(final ClassNode classNode, final MethodNode method) {
        if (method.name.equals("handler$send$zze000") || method.name.equals("handler$send$zza000")) {
            final InsnList hookInsn = new InsnList();
            final LabelNode L0 = new LabelNode();
            hookInsn.add((AbstractInsnNode)new VarInsnNode(25, 1));
            hookInsn.add((AbstractInsnNode)new MethodInsnNode(184, Type.getInternalName((Class)NetworkManagerTransformer.class), "macProcessSendPacket", "(Ljava/lang/Object;)Z"));
            hookInsn.add((AbstractInsnNode)new JumpInsnNode(153, L0));
            hookInsn.add((AbstractInsnNode)new InsnNode(177));
            hookInsn.add((AbstractInsnNode)L0);
            method.instructions.insert(hookInsn);
            System.out.println("Transformed NetworkManager handler$send$zze000");
        }
        if (method.name.equals("handler$read$zze000") || method.name.equals("handler$read$zza000")) {
            final InsnList hookInsn = new InsnList();
            final LabelNode L0 = new LabelNode();
            hookInsn.add((AbstractInsnNode)new VarInsnNode(25, 1));
            hookInsn.add((AbstractInsnNode)new MethodInsnNode(184, Type.getInternalName((Class)NetworkManagerTransformer.class), "macProcessRevPacket", "(Ljava/lang/Object;)Z"));
            hookInsn.add((AbstractInsnNode)new JumpInsnNode(153, L0));
            hookInsn.add((AbstractInsnNode)new InsnNode(177));
            hookInsn.add((AbstractInsnNode)L0);
            method.instructions.insert(hookInsn);
            System.out.println("Transformed NetworkManager handler$read$zze000");
        }
    }
    
    public static boolean macProcessSendPacket(final Object packet) {
        final Packet p = (Packet)packet;
        return p instanceof C02PacketUseEntity;
    }
    
    public static boolean macProcessRevPacket(final Object packet) {
        final Packet p = (Packet)packet;
        return p instanceof C02PacketUseEntity;
    }
}
