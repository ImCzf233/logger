package dev.ss.world.event.mixinevents;

import dev.ss.world.event.eventapi.events.Event;

public class EventUpdate implements Event
{
}
