package dev.ss.world.event.mixinevents;

import net.minecraft.entity.EntityLivingBase;
import dev.ss.world.event.eventapi.events.Event;

public class EventAttack implements Event
{
    public EntityLivingBase target;
    
    public EventAttack(EntityLivingBase ent) {
        ent = this.target;
    }
}
