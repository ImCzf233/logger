package dev.ss.world.event.eventapi.events;

public interface Event
{
}
