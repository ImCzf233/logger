package dev.ss.world.event.eventapi.types;

public enum EventType
{
    PRE, 
    ON, 
    POST, 
    SEND, 
    RECIEVE;
}
