package dev.ss.world;

import java.util.HashSet;
import java.security.ProtectionDomain;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import dev.ss.world.transformers.EntityRendererTransformer;
import dev.ss.world.transformers.NetworkManagerTransformer;
import dev.ss.world.transformers.EntityPlayerMPTransformer;
import dev.ss.world.transformers.EntityPlayerSPTransformer;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.ClassNode;
import java.util.function.BiConsumer;
import java.util.Set;
import org.objectweb.asm.Opcodes;
import dev.ss.world.instrument.ClassTransformer;

public class SSTransformer implements ClassTransformer, Opcodes
{
    public static Set<String> classNameSet;
    
    public static boolean needTransform(final String string) {
        return SSTransformer.classNameSet.contains(string);
    }
    
    private byte[] transformMethods(final byte[] byArray, final BiConsumer<ClassNode, MethodNode> biConsumer) {
        final ClassReader classReader = new ClassReader(byArray);
        final ClassNode classNode = new ClassNode();
        final ClassWriter classWriter = new ClassWriter(0);
        try {
            classReader.accept((ClassVisitor)classNode, 0);
            classNode.methods.forEach(arg_0 -> transformMethods(biConsumer, classNode, arg_0));
            classNode.accept((ClassVisitor)classWriter);
        }
        catch (Throwable t) {}
        return classWriter.toByteArray();
    }
    
    public byte[] transform(final String string, final byte[] byArray) {
        try {
            switch (string) {
                case "net.minecraft.client.entity.EntityPlayerSP": {
                    return this.transformMethods(byArray, EntityPlayerSPTransformer::transformEntityPlayerSP);
                }
                case "net.minecraft.client.multiplayer.PlayerControllerMP": {
                    return this.transformMethods(byArray, EntityPlayerMPTransformer::transformRange);
                }
                case "net.minecraft.network.NetworkManager": {
                    return this.transformMethods(byArray, NetworkManagerTransformer::transformNetworkManager);
                }
                case "net.minecraft.client.renderer.EntityRenderer": {
                    return this.transformMethods(byArray, EntityRendererTransformer::transformEntityRenderer);
                }
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
            LogManager.getLogger().log(Level.ERROR, ExceptionUtils.getStackTrace((Throwable)exception));
        }
        return byArray;
    }
    
    @Override
    public byte[] transform(final ClassLoader classLoader, final String string, final Class<?> clazz, final ProtectionDomain protectionDomain, final byte[] byArray) {
        return this.transform(clazz.getName(), byArray);
    }
    
    private static void transformMethods(final BiConsumer biConsumer, final ClassNode classNode, final MethodNode methodNode) {
        biConsumer.accept(classNode, methodNode);
    }
    
    static {
        SSTransformer.classNameSet = new HashSet<String>();
        final String[] stringArray = { "net/minecraft/network/NetworkManager", "net/minecraft/client/entity/EntityPlayerSP" };
        for (int i = 0; i < stringArray.length; ++i) {
            SSTransformer.classNameSet.add(stringArray[i]);
        }
    }
}
